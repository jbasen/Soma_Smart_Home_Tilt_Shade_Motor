﻿using System.Reflection;

[assembly: AssemblyTitle("Soma_Tilt_Shades")]
[assembly: AssemblyCompany("HP Inc.")]
[assembly: AssemblyProduct("Soma_Tilt_Shades")]
[assembly: AssemblyCopyright("Copyright © HP Inc. 2020")]
[assembly: AssemblyVersion("1.0.0.*")]

