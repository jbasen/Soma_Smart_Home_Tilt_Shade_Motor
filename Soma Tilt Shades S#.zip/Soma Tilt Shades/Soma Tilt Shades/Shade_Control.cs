﻿using System;
using System.Text;
using Crestron.SimplSharp;                          				// For Basic SIMPL# Classes
using Crestron.SimplSharp.Net.Http;

namespace Soma_Tilt_Shades
{
	#region Enum
	enum Debug_Options
	{
		None,								//Don't do anything with debug information
		Console,							//Output debug information to the console
		Error_Log,							//Send debug information to the error log
		Both								//Send debug infomation to both the console and error log
	};
	#endregion

	public class Shade_Control
	{
		#region Declarations
		private static Debug_Options Debug;
		private static string Controller_IP_Address = "";
		private const short tens_of_mV_to_MV = 10;
		#endregion

		//****************************************************************************************
		// 
		//  Shade_Control	-	Default Constructo
		// 
		//****************************************************************************************
		public Shade_Control()
		{
		}

		//****************************************************************************************
		// 
		//  Initialize	-	Module Initialization
		// 
		//****************************************************************************************
		public void Initialize(string Controller_IP_Address, short Debug)
		{
			Set_Debug_Message_Output(Debug);

			Debug_Message("Initialize", "Controller_IP_Address = " + Controller_IP_Address);

			#region Save Globals
			Shade_Control.Controller_IP_Address = Controller_IP_Address;
			#endregion

		}

		//****************************************************************************************
		// 
		//  List_Devices	-	Send List of Devices to the console and/or error log
		// 
		//****************************************************************************************
		public void List_Devices(short To_Console, short To_Error_Log)
		{
			int start_index, end_index;
			int length;
			int offset = 0;
			string s; //holder for response string

			#region Error Checking
			//Make sure initialization was called
			if (Shade_Control.Controller_IP_Address == "")
			{
				string err = "Soma_Tilt_Shades - List_Devices - List_Devices called before Initialization";
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				return;
			}
			#endregion

			#region Formulate URL
			string url = "http://" + Shade_Control.Controller_IP_Address + ":3000/list_devices";
			Debug_Message("List_Devices", "URL: " + url);
			#endregion

			#region Send http request
			try
			{
				// Perform the conversion from one encoding to the other.
				//Create http client
				HttpClient client = new HttpClient();
				//client.Verbose = true;
				HttpClientRequest request = new HttpClientRequest();
				HttpClientResponse response;

				//Send http client request
				request.KeepAlive = false;
				request.Encoding = Encoding.UTF8;
				request.RequestType = Crestron.SimplSharp.Net.Http.RequestType.Get;
				request.Url.Parse(url);
				Debug_Message("List_Devices", "Parsed URL = " + request.Url.ToString());

				//Get response
				response = client.Dispatch(request);
				if (response.Code < 200 || response.Code >= 300)
				{
					// Soma Controller threw an error.
					string err = "Soma_Tilt_Shades - List_Devices - http response code: " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
					return;
				}

				//capture response
				s = response.ContentString;
			}
			catch (Exception e)
			{
				string err = "Soma_Tilt_Shades - List_Devices - Error Sending Device Command: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				return;
			}
			#endregion

			#region Display Device List
			s = Parse_Data_Substring(s, "", "[", "]");
			start_index = s.IndexOf("{", offset);
			while (start_index != -1)											//loop while there is an open brace
			{
				end_index = s.IndexOf("}", start_index);						//associated closing brace
				length = (end_index - start_index) + 1;							//calculate length of entry
				string sub = s.Substring(start_index, length);					//extract substring
				if (To_Console == 1)
				{
					CrestronConsole.PrintLine("Soma_Tilt_Shades - List_Devices" + " - " + sub);
				}

				if (To_Error_Log == 1)
				{
					Crestron.SimplSharp.ErrorLog.Notice("Soma_Tilt_Shades - List_Devices" + " - " + sub + "\n");
				}
				offset = end_index;												//start next search at ending }
				start_index = s.IndexOf("{", offset);							//look for open brace of next entry
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Get_Battery_Level	-	returns the battery level in mV.
		//                          Zero returned in case of error
		// 
		//****************************************************************************************
		public short Get_Battery_Level(string Shade_MAC_Address)
		{
			string s; //holder for response string

			#region Error Checking
			//Make sure initialization was called
			if (Shade_Control.Controller_IP_Address == "")
			{
				string err = "Soma_Tilt_Shades - Get_Battery_Level - Get_Battery_Level called before Initialization";
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				return 0;
			}
			#endregion

			#region Formulate URL
			string url = "http://" + Shade_Control.Controller_IP_Address + ":3000/get_battery_level/" + Shade_MAC_Address;
			Debug_Message("Get_Battery_Level", "URL: " + url);
			#endregion

			#region Send http request
			try
			{
				// Perform the conversion from one encoding to the other.
				//Create http client
				HttpClient client = new HttpClient();
				//client.Verbose = true;
				HttpClientRequest request = new HttpClientRequest();
				HttpClientResponse response;

				//Send http client request
				request.KeepAlive = false;
				request.Encoding = Encoding.UTF8;
				request.RequestType = Crestron.SimplSharp.Net.Http.RequestType.Get;
				request.Url.Parse(url);
				Debug_Message("Get_Battery_Level", "Parsed URL = " + request.Url.ToString());

				//Get response
				response = client.Dispatch(request);
				if (response.Code < 200 || response.Code >= 300)
				{
					// Soma Controller threw an error.
					string err = "Soma_Tilt_Shades - Get_Battery_Level - http response code: " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
					return 0;
				}

				//capture response
				s = response.ContentString;
				Debug_Message("Get_Battery_Level", "ContentString = " + s);
			}
			catch (Exception e)
			{
				string err = "Soma_Tilt_Shades - Get_Battery_Level - Error Sending Device Command: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				return 0;
			}
			#endregion

			#region Pass Back Battery Level
			s = Parse_Data_Substring(s, "", "\"battery_level\":", "}");//parse returned json
			int battery_level = int.Parse(s) * 10;//convert to mV from tens of mV
			return (Int16)battery_level;
			#endregion
		}

		//****************************************************************************************
		// 
		//  Set_Shade_Position	-	Sets Shade to the specified position
		// 
		//****************************************************************************************
		public void Set_Shade_Position(string Shade_MAC_Address, short Position)
		{
			#region Error Checking
			//Make sure initialization was called
			if (Shade_Control.Controller_IP_Address == "")
			{
				string err = "Soma_Tilt_Shades - Get_Battery_Level - Get_Battery_Level called before Initialization";
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				return;
			}

			if ((Position < 0) || (Position > 100))
			{
				string err = "Soma_Tilt_Shades - Set_Shade_Position - Position out of range, Value = " + Position;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				return;
			}
			#endregion

			#region Formulate URL
			string url = "http://" + Shade_Control.Controller_IP_Address + ":3000/set_shade_position/" + Shade_MAC_Address + "/" + Position;
			Debug_Message("Set_Shade_Position", "URL: " + url);
			#endregion

			#region Send http request
			try
			{
				// Perform the conversion from one encoding to the other.
				//Create http client
				HttpClient client = new HttpClient();
				//client.Verbose = true;
				HttpClientRequest request = new HttpClientRequest();
				HttpClientResponse response;

				//Send http client request
				request.KeepAlive = false;
				request.Encoding = Encoding.UTF8;
				request.RequestType = Crestron.SimplSharp.Net.Http.RequestType.Get;
				request.Url.Parse(url);
				Debug_Message("Set_Shade_Position", "Parsed URL = " + request.Url.ToString());

				//Get response
				response = client.Dispatch(request);
				if (response.Code < 200 || response.Code >= 300)
				{
					// Soma Controller threw an error.
					string err = "Soma_Tilt_Shades - Set_Shade_Position - http response code: " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
					return;
				}
			}
			catch (Exception e)
			{
				string err = "Soma_Tilt_Shades - Set_Shade_Position - Error Sending Device Command: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				return;
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Get_Shade_Position	-	returns the shade position (0-100)
		//                          or -1 in the case of an error
		// 
		//****************************************************************************************
		public short Get_Shade_Position(string Shade_MAC_Address)
		{
			string s; //holder for response string

			#region Error Checking
			//Make sure initialization was called
			if (Shade_Control.Controller_IP_Address == "")
			{
				string err = "Soma_Tilt_Shades - Get_Shade_Position - Get_Shade_Position called before Initialization";
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				return -1;
			}
			#endregion

			#region Formulate URL
			string url = "http://" + Shade_Control.Controller_IP_Address + ":3000/get_shade_state/" + Shade_MAC_Address;
			Debug_Message("Get_Shade_Position", "URL: " + url);
			#endregion

			#region Send http request
			try
			{
				// Perform the conversion from one encoding to the other.
				//Create http client
				HttpClient client = new HttpClient();
				//client.Verbose = true;
				HttpClientRequest request = new HttpClientRequest();
				HttpClientResponse response;

				//Send http client request
				request.KeepAlive = false;
				request.Encoding = Encoding.UTF8;
				request.RequestType = Crestron.SimplSharp.Net.Http.RequestType.Get;
				request.Url.Parse(url);
				Debug_Message("Get_Shade_Position", "Parsed URL = " + request.Url.ToString());

				//Get response
				response = client.Dispatch(request);
				if (response.Code < 200 || response.Code >= 300)
				{
					// Soma Controller threw an error.
					string err = "Soma_Tilt_Shades - Get_Shade_Position - http response code: " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
					return -1;
				}

				//capture response
				s = response.ContentString;
				Debug_Message("Get_Shade_Position", "ContentString = " + s);
			}
			catch (Exception e)
			{
				string err = "Soma_Tilt_Shades - Get_Shade_Position - Error Sending Device Command: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				return -1;
			}
			#endregion

			#region Pass Back Position
			s = Parse_Data_Substring(s, "", "\"position\":", "}");//parse returned json
			Debug_Message("Get_Shade_Position", "Position = " + s);
			return short.Parse(s);
			#endregion
		}

		//****************************************************************************************
		// 
		//  Open_Shade	-	Opens the specified shade
		// 
		//****************************************************************************************
		public void Open_Shade(string Shade_MAC_Address)
		{
			#region Error Checking
			//Make sure initialization was called
			if (Shade_Control.Controller_IP_Address == "")
			{
				string err = "Soma_Tilt_Shades - Open_Shade - Open_Shade called before Initialization";
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				return;
			}
			#endregion

			#region Formulate URL
			string url = "http://" + Shade_Control.Controller_IP_Address + ":3000/open_shade/" + Shade_MAC_Address;
			Debug_Message("Open_Shade", "URL: " + url);
			#endregion

			#region Send http request
			try
			{
				// Perform the conversion from one encoding to the other.
				//Create http client
				HttpClient client = new HttpClient();
				//client.Verbose = true;
				HttpClientRequest request = new HttpClientRequest();
				HttpClientResponse response;

				//Send http client request
				request.KeepAlive = false;
				request.Encoding = Encoding.UTF8;
				request.RequestType = Crestron.SimplSharp.Net.Http.RequestType.Get;
				request.Url.Parse(url);
				Debug_Message("Open_Shade", "Parsed URL = " + request.Url.ToString());

				//Get response
				response = client.Dispatch(request);
				if (response.Code < 200 || response.Code >= 300)
				{
					// Soma Controller threw an error.
					string err = "Soma_Tilt_Shades - Open_Shade - http response code: " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
					return;
				}
			}
			catch (Exception e)
			{
				string err = "Soma_Tilt_Shades - Open_Shade - Error Sending Device Command: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				return;
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Close_Shade	-	Closes the specified shade
		// 
		//****************************************************************************************
		public void Close_Shade(string Shade_MAC_Address)
		{
			#region Error Checking
			//Make sure initialization was called
			if (Shade_Control.Controller_IP_Address == "")
			{
				string err = "Soma_Tilt_Shades - Close_Shade - Close_Shade called before Initialization";
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				return;
			}
			#endregion

			#region Formulate URL
			string url = "http://" + Shade_Control.Controller_IP_Address + ":3000/close_shade/" + Shade_MAC_Address;
			Debug_Message("Close_Shade", "URL: " + url);
			#endregion

			#region Send http request
			try
			{
				// Perform the conversion from one encoding to the other.
				//Create http client
				HttpClient client = new HttpClient();
				//client.Verbose = true;
				HttpClientRequest request = new HttpClientRequest();
				HttpClientResponse response;

				//Send http client request
				request.KeepAlive = false;
				request.Encoding = Encoding.UTF8;
				request.RequestType = Crestron.SimplSharp.Net.Http.RequestType.Get;
				request.Url.Parse(url);
				Debug_Message("Close_Shade", "Parsed URL = " + request.Url.ToString());

				//Get response
				response = client.Dispatch(request);
				if (response.Code < 200 || response.Code >= 300)
				{
					// Soma Controller threw an error.
					string err = "Soma_Tilt_Shades - Close_Shade - http response code: " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
					return;
				}
			}
			catch (Exception e)
			{
				string err = "Soma_Tilt_Shades - Close_Shade - Error Sending Device Command: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				return;
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Stop_Shade	-	Stops the specified shade
		// 
		//****************************************************************************************
		public void Stop_Shade(string Shade_MAC_Address)
		{
			#region Error Checking
			//Make sure initialization was called
			if (Shade_Control.Controller_IP_Address == "")
			{
				string err = "Soma_Tilt_Shades - Stop_Shade - Stop_Shade called before Initialization";
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				return;
			}
			#endregion

			#region Formulate URL
			string url = "http://" + Shade_Control.Controller_IP_Address + ":3000/stop_shade/" + Shade_MAC_Address;
			Debug_Message("Stop_Shade", "URL: " + url);
			#endregion

			#region Send http request
			try
			{
				// Perform the conversion from one encoding to the other.
				//Create http client
				HttpClient client = new HttpClient();
				//client.Verbose = true;
				HttpClientRequest request = new HttpClientRequest();
				HttpClientResponse response;

				//Send http client request
				request.KeepAlive = false;
				request.Encoding = Encoding.UTF8;
				request.RequestType = Crestron.SimplSharp.Net.Http.RequestType.Get;
				request.Url.Parse(url);
				Debug_Message("Stop_Shade", "Parsed URL = " + request.Url.ToString());

				//Get response
				response = client.Dispatch(request);
				if (response.Code < 200 || response.Code >= 300)
				{
					// Soma Controller threw an error.
					string err = "Soma_Tilt_Shades - Stop_Shade - http response code: " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
					return;
				}
			}
			catch (Exception e)
			{
				string err = "Soma_Tilt_Shades - Stop_Shade - Error Sending Device Command: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				return;
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Parse_Data_Substring	-	Parse Data Element from Json
		// 
		//****************************************************************************************
		private string Parse_Data_Substring(string s, string section, string id, string ending_char)
		{
			int index1, index2, section_index;

			//if data element located within a specific section of json, go to that section
			if (section != "")
			{
				section_index = s.IndexOf(section, 0);
				if (section_index == -1)
				{
					CrestronConsole.PrintLine("Soma_Tilt_Shades - Parse_Data_Substring - Unable to Locate " + section + " in " + s);
					Crestron.SimplSharp.ErrorLog.Error("Soma_Tilt_Shades - Parse_Data_Substring - Unable to Locate " + section + " in " + s);
					return "";
				}
				else
				{
					section_index += section.Length;
				}
			}
			else
			{
				section_index = 0;
			}

			//get index to start of value
			index1 = s.IndexOf(id, section_index);
			if (index1 == -1)
			{
				CrestronConsole.PrintLine("Soma_Tilt_Shades - Parse_Data_Substring - Unable to Locate " + id + " in " + s);
				Crestron.SimplSharp.ErrorLog.Error("Soma_Tilt_Shades - Parse_Data_Substring - Unable to Locate " + id + " in " + s);
				return "";
			}
			else
			{
				index1 += id.Length;
			}

			//get index to end of value
			index2 = s.IndexOf(ending_char, (index1 + 1));
			if (index2 == -1)
			{
				CrestronConsole.PrintLine("Soma_Tilt_Shades - Parse_Data_Substring - Unable to Locate terminating " + ending_char + " for " + id + " in " + s);
				Crestron.SimplSharp.ErrorLog.Error("Soma_Tilt_Shades - Parse_Data_Substring - Unable to Locate terminating " + ending_char + " for " + id + " in " + s);
				return "";
			}

			//get value substring and pass it back
			return s.Substring(index1, index2 - index1);
		}

		//****************************************************************************************
		// 
		//  Set_Debug_Message_Output	-	Save whether debug messages will be output
		//									to console, error log, both, or not sent
		//									0 = None, 1 = Console, 2 = Error Log, 3 = Both
		// 
		//****************************************************************************************
		public void Set_Debug_Message_Output(short Debug)
		{
			//Save debug message setting as an enum
			switch (Debug)
			{
				case 0:
					Shade_Control.Debug = Debug_Options.None;
					break;

				case 1:
					Shade_Control.Debug = Debug_Options.Console;
					break;

				case 2:
					Shade_Control.Debug = Debug_Options.Error_Log;
					break;

				case 3:
					Shade_Control.Debug = Debug_Options.Both;
					break;
			}
		}

		//****************************************************************************************
		// 
		//  Debug_Message	-	Send Debug Message to Console or Error Log
		//						Depending on Selection
		// 
		//****************************************************************************************
		private static void Debug_Message(string Name, string s)
		{
			const int characters_per_line = 250;
			int start_index = 0;
			int length = characters_per_line;

			//json responses are too large for Simpl Debugger to display on a single line
			//so, we break them up into chunks of 250 characters to be printed on 1 line
			while (start_index < s.Length)
			{
				if ((start_index + characters_per_line) > s.Length)
				{
					length = s.Length - start_index;
				}

				string sub = s.Substring(start_index, length);

				if ((Debug == Debug_Options.Console) || (Debug == Debug_Options.Both))
				{
					CrestronConsole.PrintLine("Soma_Tilt_Shades - " + Name + " - " + sub);
				}

				if ((Debug == Debug_Options.Error_Log) || (Debug == Debug_Options.Both))
				{
					Crestron.SimplSharp.ErrorLog.Notice("Soma_Tilt_Shades - " + Name + " - " + sub + "\n");
				}

				start_index += characters_per_line;
			}
		}
	}
}
